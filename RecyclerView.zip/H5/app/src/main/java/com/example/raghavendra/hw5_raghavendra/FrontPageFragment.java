package com.example.raghavendra.hw5_raghavendra;

/**
 * Created by Raghavendra on 2/22/2016.
 */
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.HashMap;

public class FrontPageFragment extends Fragment {
    private static final String ARG_SECTION_NUMBER = "section_number";

        /*MovieData movieData = new MovieData();*/

    public FrontPageFragment() {
        // Required empty public constructor

    }

    public static FrontPageFragment newInstance(HashMap<String, ?> sectionNumber) {
        FrontPageFragment fragment = new FrontPageFragment();
        Bundle args = new Bundle();
        args.putSerializable(ARG_SECTION_NUMBER, sectionNumber);
        fragment.setArguments(args);

        return fragment;
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setHasOptionsMenu(true);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View rootView;
        rootView = inflater.inflate(R.layout.fragment_front_page, container, false);

        return rootView;
    }

}


