package com.example.raghavendra.hw5_raghavendra;

/**
 * Created by Raghavendra on 2/23/2016.
 */

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.NavigationView;
import android.support.v4.app.Fragment;
import android.support.v4.app.NavUtils;
import android.support.v4.view.GravityCompat;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;

import java.util.HashMap;

public class Task3Activity extends MainActivity implements RecyclerViewFragment.OnEachCardSelectedListener, NavigationView.OnNavigationItemSelectedListener {
    private Fragment mContent;
    MovieData movieData= new MovieData();
    //private NavigationView navigationView;
    //private DrawerLayout drawerLayout;
    //private Toolbar toolbar;
    private Toolbar toolbarBottom;

/*    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        return super.onOptionsItemSelected(item);
    }*/

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        LayoutInflater inflater = (LayoutInflater) this.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View contentView = inflater.inflate(R.layout.activity_task3, null, false);
        drawerLayout.addView(contentView, 0);

        toolbarBottom = (Toolbar) findViewById(R.id.toolbar_bottom);
        toolbarBottom.inflateMenu(R.menu.menu_main);
        setUpToolBarItemSelected();

        HashMap<String,?> movie = (HashMap<String,?>) movieData.getItem(1);

/*        if(savedInstanceState!=null)
        {
            mContent = getSupportFragmentManager().getFragment(savedInstanceState, "mContent");
        }
        else{
            mContent = RecyclerViewFragment.newInstance(movie);
        }*/
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.container, RecyclerViewFragment.newInstance(movie))
                .commit();
        ImageView img = (ImageView)findViewById(R.id.toolbarimg2);


        if(img!=null){
            img.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                   // System.out.println("Are you clicking ???????????????????????????");

                    toolbarBottom.setVisibility(View.VISIBLE);
                }
            });
        }

        ImageButton goBack=(ImageButton)  toolbarBottom.findViewById(R.id.goback);
        ImageButton goHome=(ImageButton) toolbarBottom.findViewById(R.id.gohome);
        if(goHome!=null)
        {
            goHome.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                 //  finish();
                    Intent intent=new Intent(Task3Activity.this,MainActivity.class);
                    startActivity(intent);
                   // setContentView(R.layout.activity_main);


                }
            });
        }

        if(goBack!=null)
        {
            goBack.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    onBackPressed();

                }
            });
        }
    }

    private void setUpToolBarItemSelected() {
        toolbarBottom.setOnMenuItemClickListener(new Toolbar.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                int id = item.getItemId();
                switch (id) {
                    case R.id.task0:
                    {
                       //  System.out.println("task0 ???????????????????????????");

                        return true;

                    }
                    case R.id.task1:
                    {
                        //System.out.println("task1 ???????????????????????????");

                        return true;

                    }
                    default:
                        break;
                }
                return false;
            }
        });
        toolbarBottom.setNavigationIcon(R.drawable.visibilityoff);
        toolbarBottom.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int id=v.getId();
                toolbarBottom.setVisibility(View.GONE);


            }

        });


    }
/*
    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        if(!mContent.isAdded())
            getSupportFragmentManager().putFragment(outState, "mContent", mContent);
    }*/

    @Override
    public void OnEachCardSelected(int position, HashMap<String, ?> movie) {
        mContent =  MovieDetailFragment.newInstance(movie);
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.container, MovieDetailFragment.newInstance(movie))
                .addToBackStack(null)
                .commit();
    }


    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        int id = item.getItemId();
        switch (id){
            case R.id.item1:
                Intent intent = new Intent(this, MainActivity.class);
                startActivity(intent);
                break;
            case R.id.item2:
                Intent intent2 = new Intent(this, Task2Activity.class);
                startActivity(intent2);
                break;
            case R.id.item3:
                break;
        }
        drawerLayout.closeDrawer(GravityCompat.START);
        return true;
    }


}
