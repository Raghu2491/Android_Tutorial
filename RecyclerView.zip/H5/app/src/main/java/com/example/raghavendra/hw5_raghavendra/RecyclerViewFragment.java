package com.example.raghavendra.hw5_raghavendra;

/**
 * Created by Raghavendra on 2/22/2016.
 */
import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.SearchView;
import android.view.ActionMode;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.OvershootInterpolator;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.PopupMenu;
import android.widget.Toast;

import com.baoyz.widget.PullRefreshLayout;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

import jp.wasabeef.recyclerview.adapters.AlphaInAnimationAdapter;
import jp.wasabeef.recyclerview.adapters.SlideInBottomAnimationAdapter;
import jp.wasabeef.recyclerview.animators.FlipInBottomXAnimator;


public class RecyclerViewFragment extends Fragment {
    private RecyclerView mRecyclerView;
    private RecyclerView.LayoutManager mLayoutManager;
    MovieData movieData=new MovieData();
    PullRefreshLayout layout = null;
    private MyRecyclerViewAdapter mRecyclerViewAdapter;
    private static final String ARG_SECTION_NUMBER = "section_number";


    public interface OnEachCardSelectedListener{
        void OnEachCardSelected(int position, HashMap<String, ?> movie);
    }

    OnEachCardSelectedListener mListener;

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        if(menu.findItem(R.id.action_search)==null)
            inflater.inflate(R.menu.menu_fragment_task,menu);

        SearchView search = (SearchView) menu.findItem(R.id.action_search).getActionView();

        if(search!=null){
            final List<Map<String,?>> movieList = movieData.getMoviesList();
            search.setOnQueryTextListener(new SearchView.OnQueryTextListener() {

                @Override
                public boolean onQueryTextSubmit(String query) {
                    String delims = " ";
                    int count=0;

                    for(int i=0;i<movieList.size();i++){
                        StringTokenizer st = new StringTokenizer(movieList.get(i).get("name").toString().toLowerCase(),delims);
                        while(st.hasMoreElements()){
                            if(st.nextElement().equals(query.toLowerCase())){
                                if(count>=0) {
                                    mRecyclerView.scrollToPosition(count);
                                    return true;
                                }
                            }
                        }
                        count++;
                    }
                    return false;
                }

                @Override
                public boolean onQueryTextChange(String newText) {
                    return true;
                }
            });
        }

      

        super.onCreateOptionsMenu(menu, inflater);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        return super.onOptionsItemSelected(item);
    }

    public RecyclerViewFragment() {
        // Required empty public constructor

    }

    public static RecyclerViewFragment newInstance(HashMap<String, ?> sectionNumber) {
        RecyclerViewFragment fragment = new RecyclerViewFragment();
        Bundle args = new Bundle();
        args.putSerializable(ARG_SECTION_NUMBER, sectionNumber);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);

        try{
            mListener =  (OnEachCardSelectedListener)getContext();
        }
        catch(ClassCastException exception){
            throw new ClassCastException(context.toString()
                    + " must implement OnHeadlineSelectedListener");
        }

    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        /*setRetainInstance(true);*/
        setHasOptionsMenu(true);
    }

    @Override
    public View onCreateView(final LayoutInflater inflater, final ViewGroup container,
                             final Bundle savedInstanceState) {

        final View rootView;
        // Inflate the layout for this fragment
        rootView = inflater.inflate(R.layout.fragment_recycler_view, container, false);
        mRecyclerView = (RecyclerView) rootView.findViewById(R.id.cardList);
        mRecyclerView.setHasFixedSize(true);
        mLayoutManager = new LinearLayoutManager(getActivity());
        mRecyclerView.setLayoutManager(mLayoutManager);
        mRecyclerViewAdapter = new MyRecyclerViewAdapter(getActivity(), movieData.getMoviesList());

        mRecyclerView.setAdapter(mRecyclerViewAdapter);
        itemAnimation();
        adapterAnimation();


        layout = (PullRefreshLayout) rootView.findViewById(R.id.swipeRefreshLayout);
        layout.setOnRefreshListener(new PullRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                mRecyclerViewAdapter.notifyItemRangeChanged(0, mRecyclerViewAdapter.getItemCount());
                Toast.makeText(getContext(),"Refreshed",Toast.LENGTH_LONG).show();
                layout.setRefreshing(false);
            }
        });
        layout.setRefreshStyle(PullRefreshLayout.STYLE_MATERIAL);

        mRecyclerViewAdapter.setOnCardClickListener(new MyRecyclerViewAdapter.onCardClickListener() {
            @Override
            public void onCardClick(View view, int position) {
                HashMap<String, ?> movie = (HashMap<String, ?>) movieData.getItem(position);
                mListener.OnEachCardSelected(position, movie);
            }

            @Override
            public void onCardLongClick(View view, int position) {
                getActivity().startActionMode(new ActionBarCallBack(position));
            }

            @Override
            public void onMoreOptionsClick(View view, final int position) {
                PopupMenu popupmenu = new PopupMenu(getActivity(),view);
                popupmenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    @Override
                    public boolean onMenuItemClick(MenuItem item) {
                        switch (item.getItemId()){
                            case R.id.action_delete:
                                List<Map<String,?>> maps = movieData.getMoviesList();
                                maps.remove(position);
                                mRecyclerViewAdapter.notifyItemRemoved(position);
                                return true;
                            case R.id.action_duplicate:
                                List<Map<String,?>> maps2 = movieData.getMoviesList();
                                maps2.add(position+1, (HashMap) ((HashMap<String, ?>) movieData.getItem(position)).clone());
                                mRecyclerViewAdapter.notifyItemInserted(position+1);
                                return true;
                            default:
                                return false;
                        }
                    }
                });
                MenuInflater inflater = popupmenu.getMenuInflater();
                inflater.inflate(R.menu.menu_popup,popupmenu.getMenu());
                popupmenu.show();
            }
        });

        return rootView;
    }
    private void itemAnimation(){
        FlipInBottomXAnimator animator = new FlipInBottomXAnimator();
        animator.setAddDuration(300);
        animator.setRemoveDuration(300);
        mRecyclerView.setItemAnimator(animator);
    }

    private void adapterAnimation(){
        AlphaInAnimationAdapter alphaAdapter = new AlphaInAnimationAdapter(mRecyclerViewAdapter);
        SlideInBottomAnimationAdapter slideAdapter = new SlideInBottomAnimationAdapter(alphaAdapter);
        slideAdapter.setDuration(1000);
        slideAdapter.setInterpolator(new OvershootInterpolator());
        slideAdapter.setFirstOnly(false);
        mRecyclerView.setAdapter(slideAdapter);
    }

    private class ActionBarCallBack implements ActionMode.Callback {
        int position;

        public ActionBarCallBack(int position) {
            this.position = position;
        }

        @Override
        public boolean onCreateActionMode(ActionMode mode, Menu menu) {
            mode.getMenuInflater().inflate(R.menu.menu_popup,menu);
            return true;
        }

        @Override
        public boolean onPrepareActionMode(ActionMode mode, Menu menu) {
            HashMap<String,?> movie = (HashMap<String,?>) movieData.getItem(position);
            mode.setTitle((String) movie.get("name"));
            return false;
        }

        @Override
        public boolean onActionItemClicked(ActionMode mode, MenuItem item) {
            int id = item.getItemId();

            switch (id){

                case R.id.action_delete:
                    List<Map<String,?>> maps = movieData.getMoviesList();
                    maps.remove(position);
                    mRecyclerViewAdapter.notifyItemRemoved(position);
                    mode.finish();
                    break;
                case R.id.action_duplicate:
                    List<Map<String,?>> maps2 = movieData.getMoviesList();
                    maps2.add(position+1, (HashMap) ((HashMap<String, ?>) movieData.getItem(position)).clone());
                    mRecyclerViewAdapter.notifyItemInserted(position+1);
                    mode.finish();
                    break;
                default:
                    break;
            }
            return false;
        }

        @Override
        public void onDestroyActionMode(ActionMode mode) {

        }
    }

}
