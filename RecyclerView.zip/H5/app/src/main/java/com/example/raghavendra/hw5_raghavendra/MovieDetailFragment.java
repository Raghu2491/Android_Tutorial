package com.example.raghavendra.hw5_raghavendra;

/**
 * Created by Raghavendra on 2/22/2016.
 */
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.view.MenuItemCompat;
import android.support.v7.widget.ShareActionProvider;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;

import java.util.HashMap;


public class MovieDetailFragment extends Fragment {
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_SECTION_NUMBER = "section_number";

    MovieData movieData=new MovieData();
    HashMap movie;
    private ShareActionProvider mShareActionProvider;

    public MovieDetailFragment() {
        // Required empty public constructor

    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param sectionNumber Parameter 1.
     * @return A new instance of fragment FrontPage.
     */
    // TODO: Rename and change types and number of parameters
    public static MovieDetailFragment newInstance(HashMap<String, ?> sectionNumber) {
        MovieDetailFragment fragment = new MovieDetailFragment();
        Bundle args = new Bundle();
        args.putSerializable(ARG_SECTION_NUMBER, sectionNumber);
        fragment.setArguments(args);

        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView=null;
        // Inflate the layout for this fragment
        if (getArguments() != null) {
            movie = (HashMap<String, ?>) getArguments().getSerializable(ARG_SECTION_NUMBER);
        }
        rootView = inflater.inflate(R.layout.fragment_moviedetail, container, false);

        ImageView movie_poster = (ImageView) rootView.findViewById(R.id.icon);
        TextView movie_title = (TextView) rootView.findViewById(R.id.title);
        TextView movie_stars = (TextView) rootView.findViewById(R.id.starsname);
        TextView movie_year = (TextView) rootView.findViewById(R.id.year);
        TextView movie_desc = (TextView) rootView.findViewById(R.id.descrip);
        RatingBar movie_rating = (RatingBar) rootView.findViewById(R.id.rating);
        TextView movie_director = (TextView) rootView.findViewById(R.id.directorname);
        TextView movie_rating_text = (TextView) rootView.findViewById(R.id.ratingText);

        movie_poster.setImageResource((Integer) movie.get("image"));
        movie_title.setText((String) movie.get("name"));
        movie_stars.setText((String)movie.get("stars"));
        movie_year.setText("(" + (String) movie.get("year") + ")");
        movie_desc.setText((String)movie.get("description"));
        movie_director.setText((String) movie.get("director"));
        Double rates = (Double)movie.get("rating");
        movie_rating.setRating(rates.floatValue()/2);
        movie_rating_text.setText(rates.toString());
        return rootView;
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {

        Log.i("--------------?","");

        inflater.inflate(R.menu.menu_fragement_detail, menu);
        MenuItem shareItem = menu.findItem(R.id.action_share);
        mShareActionProvider = (ShareActionProvider) MenuItemCompat.getActionProvider(shareItem);
        Intent intentShare = new Intent(Intent.ACTION_SEND);
        intentShare.setType("text/plain");
        intentShare.putExtra(Intent.EXTRA_TEXT, (String)movie.get("name"));
        mShareActionProvider.setShareIntent(intentShare);

        super.onCreateOptionsMenu(menu, inflater);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        Log.i("onOptionsItemSelected?","");

        return super.onOptionsItemSelected(item);
    }
}
