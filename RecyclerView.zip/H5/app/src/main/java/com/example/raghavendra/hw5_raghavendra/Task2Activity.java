package com.example.raghavendra.hw5_raghavendra;

/**
 * Created by Raghavendra on 2/23/2016.
 */
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.NavigationView;
import android.support.v4.app.Fragment;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBar;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import java.util.HashMap;


public class Task2Activity extends MainActivity implements RecyclerViewFragment.OnEachCardSelectedListener, NavigationView.OnNavigationItemSelectedListener {
    private Fragment mContent;
    MovieData movieData= new MovieData();
    private NavigationView navigationView;
    //private DrawerLayout drawerLayout;
    private Toolbar toolbar;

/*    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        return super.onOptionsItemSelected(item);
    }*/

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        LayoutInflater inflater = (LayoutInflater) this.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        View contentView = inflater.inflate(R.layout.activity_main, null, false);
        drawerLayout.addView(contentView, 0);
        HashMap<String,?> movie = (HashMap<String,?>) movieData.getItem(1);

/*        if(savedInstanceState!=null)
        {
            mContent = getSupportFragmentManager().getFragment(savedInstanceState, "mContent");
        }
        else{
            mContent = RecyclerViewFragment.newInstance(movie);
        }*/
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.container, RecyclerViewFragment.newInstance(movie))
                .commit();


        /////////////////////////////////////



    }
/*    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        if(!mContent.isAdded())
            getSupportFragmentManager().putFragment(outState, "mContent", mContent);
    }*/

    @Override
    public void OnEachCardSelected(int position, HashMap<String, ?> movie) {
        mContent =  MovieDetailFragment.newInstance(movie);
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.container, MovieDetailFragment.newInstance(movie))
                .addToBackStack(null)
                .commit();
    }

    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        int id = item.getItemId();
        switch (id){
            case R.id.item1:
                Intent intent = new Intent(this, MainActivity.class);
                startActivity(intent);
                break;
            case R.id.item2:
                break;
            case R.id.item3:
                Intent intent3 = new Intent(this, Task3Activity.class);
                startActivity(intent3);
                break;
        }
        drawerLayout.closeDrawer(GravityCompat.START);
        return true;
    }
}
