package com.example.raghavendra.movie;


import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.view.MenuItemCompat;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.ShareActionProvider;
import android.view.ActionMode;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;

//import com.baoyz.widget.PullRefreshLayout;

import com.firebase.client.Firebase;

import java.util.HashMap;

import butterknife.ButterKnife;

/*import jp.wasabeef.recyclerview.adapters.AlphaInAnimationAdapter;
import jp.wasabeef.recyclerview.adapters.SlideInBottomAnimationAdapter;
import jp.wasabeef.recyclerview.animators.FlipInBottomXAnimator;
/**
 * Created by Raghavendra on 2/22/2016.
 */

public class Movies_RecyclerViewFragment extends Fragment {

    private RecyclerView mRecyclerView;
    private RecyclerView.LayoutManager mLayoutManager;
    private ShareActionProvider mShareActionProvider;
    private Movies_MyRecyclerViewAdapter mRecyclerViewAdapter;
    Movies_MovieData moviesMovieData =new Movies_MovieData();
    private static final String ARG_SECTION_NUMBER = "section_number";
    final Firebase mRef = new Firebase("https://burning-inferno-6404.firebaseio.com/moviedata/");



    public interface OnEachCardItemSelectedListener {
        void OnEachCardSelected(int position, HashMap<String, ?> movie,View view);
    }

    OnEachCardItemSelectedListener mListener;

 /*   @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {


       /* if(search!=null){
            final List<Map<String,?>> movieList = moviesMovieData.getMoviesList();
            search.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
                @Override
                public boolean onQueryTextSubmit(String query) {
                    String delimit = " ";
                    int count=0;
                    for(int i=0;i<movieList.size();i++){
                        StringTokenizer st = new StringTokenizer(movieList.get(i).get("name").toString().toLowerCase(),delimit);
                        while(st.hasMoreElements()){
                            if(st.nextElement().equals(query.toLowerCase())){
                                if(count>=0) {
                                    mRecyclerView.scrollToPosition(count);
                                    return true;
                                }
                            }
                        }
                        count++;
                    }
                    return false;
                }

                @Override
                public boolean onQueryTextChange(String newText) {
                    return true;
                }
            });
        }

      

        super.onCreateOptionsMenu(menu, inflater);
    }*/

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        return super.onOptionsItemSelected(item);
    }

    public Movies_RecyclerViewFragment() {
        // Required empty public constructor

    }
    public static Movies_RecyclerViewFragment newInstance(HashMap<String, ?> sectionNumber) {
        Movies_RecyclerViewFragment fragment = new Movies_RecyclerViewFragment();
        Bundle args = new Bundle();
        args.putSerializable(ARG_SECTION_NUMBER, sectionNumber);
        fragment.setArguments(args);
        return fragment;
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
    }

    ///////Connect here
    @Override
    public View onCreateView(final LayoutInflater inflater, final ViewGroup container,final Bundle savedInstanceState)
    {

         View rootView;
        rootView = inflater.inflate(R.layout.fragment_movies, container, false);
        ButterKnife.bind(this, rootView);
        mRecyclerView = (RecyclerView) rootView.findViewById(R.id.movies_recycler_view);
        mRecyclerView.setHasFixedSize(true);
        mLayoutManager = new GridLayoutManager(getActivity(),2);
        mRecyclerView.setLayoutManager(mLayoutManager);
        mRecyclerViewAdapter = new Movies_MyRecyclerViewAdapter(getActivity(), moviesMovieData.getMoviesList());
        //////////////////////////////
        mRecyclerView.setAdapter(mRecyclerViewAdapter);
        Movies_MovieData movie=new Movies_MovieData();
       // itemAnimation();
        //adapterAnimation();

        /////////refresh layout

        mListener = (OnEachCardItemSelectedListener) getContext();

        mRecyclerViewAdapter.setOnCardClickListener(new Movies_MyRecyclerViewAdapter.onCardItemClickListener() {
            @Override
            public void onCardClick(View view, int position) {

                HashMap<String, ?> movie = (HashMap<String, ?>) moviesMovieData.findFirst(position);
                mListener.OnEachCardSelected(position, movie, view);


            }

            @Override
            public void onFavouredClicked(View view, int position) {

                System.out.println("Selected hearts button");
                HashMap<String, ?> movie = (HashMap<String, ?>) moviesMovieData.findFirst(position);
                mRef.child((String) movie.get("id")).setValue(movie);

            }

            @Override
            public void onNotFavouredClicked(View view, int position) {
                HashMap<String, ?> movie = (HashMap<String, ?>) moviesMovieData.findFirst(position);
                mRef.child((String) movie.get("id")).removeValue();
            }

/*
            @Override
            public void onMoreOptionsClick(View view, final int position) {
               PopupMenu popupmenu = new PopupMenu(getActivity(),view);
                popupmenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    @Override
                    public boolean onMenuItemClick(MenuItem item) {
                        switch (item.getItemId()){
                            case R.id.delete_action:
                                List<Map<String,?>> maps = moviesMovieData.getMoviesList();
                                maps.remove(position);
                                mRecyclerViewAdapter.notifyItemRemoved(position);
                                return true;
                            case R.id.duplicate_action:
                                List<Map<String,?>> maps2 = moviesMovieData.getMoviesList();
                                maps2.add(position+1, (HashMap) ((HashMap<String, ?>) moviesMovieData.findFirst(position)).clone());
                                mRecyclerViewAdapter.notifyItemInserted(position+1);
                                return true;
                            default:
                                return false;
                        }
                    }
                });
                MenuInflater inflater = popupmenu.getMenuInflater();
                inflater.inflate(R.menu.menu_redundantpopup,popupmenu.getMenu());
                popupmenu.show();
            }*/
        });

        return rootView;
    }
    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {

        inflater.inflate(R.menu.fragment_movie, menu);
        // mMenuItemShare = menu.findItem(R.id.shareaction);
        MenuItem shareItem = menu.findItem(R.id.shareaction);
        //mShareActionProvider= (ShareActionProvider) shareItem.getActionProvider();
        mShareActionProvider = (ShareActionProvider) MenuItemCompat.getActionProvider(shareItem);
        Intent intentShare = new Intent(Intent.ACTION_SEND);
        intentShare.setType("text/plain");
        intentShare.putExtra(Intent.EXTRA_TEXT, "Hhaa");
        mShareActionProvider.setShareIntent(intentShare);



        super.onCreateOptionsMenu(menu, inflater);

    }




    /* private void adapterAnimation(){
        AlphaInAnimationAdapter alphaAdapter = new AlphaInAnimationAdapter(mRecyclerViewAdapter);
        SlideInBottomAnimationAdapter slideAdapter = new SlideInBottomAnimationAdapter(alphaAdapter);
        slideAdapter.setDuration(1000);
        slideAdapter.setInterpolator(new OvershootInterpolator());
        slideAdapter.setFirstOnly(false);
        mRecyclerView.setAdapter(slideAdapter);
    }
    private void itemAnimation(){
        FlipInBottomXAnimator animator = new FlipInBottomXAnimator();
        animator.setAddDuration(300);
        animator.setRemoveDuration(300);
        mRecyclerView.setItemAnimator(animator);
    }
*/
    private class ActionBarCallBack implements ActionMode.Callback {
        int position;

        public ActionBarCallBack(int position) {
            this.position = position;
        }

        @Override
        public boolean onCreateActionMode(ActionMode mode, Menu menu) {
          //  mode.getMenuInflater().inflate(R.menu.menu_redundantpopup,menu);
            return true;
        }

        @Override
        public boolean onPrepareActionMode(ActionMode mode, Menu menu) {
            HashMap<String,?> movie = (HashMap<String,?>) moviesMovieData.findFirst(position);
            mode.setTitle((String) movie.get("name"));
            return false;
        }
        @Override
        public void onDestroyActionMode(ActionMode mode) {

        }
        @Override
        public boolean onActionItemClicked(ActionMode mode, MenuItem item) {
            int id = item.getItemId();
/*
            switch (id){

                case R.id.delete_action:
                    List<Map<String,?>> maps = moviesMovieData.getMoviesList();
                    maps.remove(position);
                    mRecyclerViewAdapter.notifyItemRemoved(position);
                    mode.finish();
                    break;
                case R.id.duplicate_action:
                    List<Map<String,?>> maps2 = moviesMovieData.getMoviesList();
                    maps2.add(position+1, (HashMap) ((HashMap<String, ?>) moviesMovieData.findFirst(position)).clone());
                    mRecyclerViewAdapter.notifyItemInserted(position+1);
                    mode.finish();
                    break;
                default:
                    break;
            }*/
            return false;
        }

    }

}
