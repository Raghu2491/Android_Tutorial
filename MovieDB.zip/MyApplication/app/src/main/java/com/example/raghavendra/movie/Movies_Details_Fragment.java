package com.example.raghavendra.movie;



import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.ShareCompat;
import android.support.v4.view.MenuItemCompat;
import android.support.v4.view.ViewCompat;
import android.support.v7.widget.ShareActionProvider;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

import com.github.ksoichiro.android.observablescrollview.ObservableScrollView;
import com.github.ksoichiro.android.observablescrollview.ObservableScrollViewCallbacks;
import com.github.ksoichiro.android.observablescrollview.ScrollState;
import com.github.ksoichiro.android.observablescrollview.ScrollUtils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import butterknife.Bind;
import butterknife.BindColor;
import butterknife.ButterKnife;

import static butterknife.ButterKnife.findById;

/**
 * Created by Raghavendra on 4/24/2016.
 */
public class Movies_Details_Fragment extends Fragment implements ObservableScrollViewCallbacks{

    private static final String ARG_SECTION_NUMBER = "section_number";
    int moviepos;
    HashMap<String,?> movie;
    private ShareActionProvider mShareActionProvider;
    Movies_MovieData moviesMovieData =new Movies_MovieData();
    private Context mContext =getContext();
    Activity activity=getActivity();
    public MediaStore.Video mvideo;
    private static final String STATE_SCROLL_VIEW = "state_scroll_view";

    @Bind(R.id.movie_cover_container) FrameLayout mCoverContainer;
    //@Bind(R.id.menu_share) MenuItem share;
    private MenuItem mMenuItemShare;
    ViewGroup mVideosGroup;
    ImageView mPosterPlayImage;
    TextView videoNameView;
    View.OnClickListener mListener;
    @Bind(R.id.movie_scroll_view) ObservableScrollView mScrollView;
    @Nullable Toolbar mToolbar;
    private List<Runnable> mDeferredUiOperations = new ArrayList<>();


    @BindColor(R.color.theme_primary) int mColorThemePrimary;
    @BindColor(R.color.body_text_white) int mColorTextWhite;

    public interface onCoverclicklistner
    {
        void inflafeyoutube(String trailerid);
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param sectionNumber Parameter 1.
     * @return A new instance of fragment FrontPage.
     */
    // TODO: Rename and change types and number of parameters
    public static Movies_Details_Fragment newInstance(HashMap<String, ?> sectionNumber) {
        Movies_Details_Fragment fragment = new Movies_Details_Fragment();
        Bundle args = new Bundle();
        args.putSerializable(ARG_SECTION_NUMBER, sectionNumber);
        fragment.setArguments(args);
        return fragment;
    }
    public Movies_Details_Fragment() {
        // Required empty public constructor

    }
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View rootView=null;
        movie = (HashMap<String,?>)getArguments().getSerializable(ARG_SECTION_NUMBER);
        rootView = inflater.inflate(R.layout.fragment_movie, container, false);
        ButterKnife.bind(this, rootView);
        trySetupToolbar();
        mScrollView.setScrollViewCallbacks(this);
        onScrollChanged(mScrollView.getCurrentScrollY(), false, false);
        ImageView movie_cover = (ImageView) rootView.findViewById(R.id.movie_cover);
        ImageView movie_poster = (ImageView) rootView.findViewById(R.id.movie_poster);
        TextView movie_title = (TextView) rootView.findViewById(R.id.movie_title);
        TextView movie_year = (TextView) rootView.findViewById(R.id.movie_release_date);
        TextView movie_desc = (TextView) rootView.findViewById(R.id.movie_overview);

       // TextView movie_stars = (TextView) rootView.findViewById(R.id.starsname);
        //RatingBar movie_rating = (RatingBar) rootView.findViewById(R.id.movierating);
        //TextView movie_director = (TextView) rootView.findViewById(R.id.directorname);
        //TextView movie_rating_text = (TextView) rootView.findViewById(R.id.movie_average_rating);


        movie_cover.setImageResource((Integer) movie.get("image"));
        movie_poster.setImageResource((Integer) movie.get("image"));
        //movie_poster.setTransitionName((String) movie.get("name"));
//        movie_title.setText((String) movie.get("name"));
        movie_year.setText("(" + movie.get("year") + ")");
        movie_desc.setText((String) movie.get("description"));
        //mListener = (onCoverclicklistner) getContext();
        //mCoverContainer = (FrameLayout) rootView.findViewById(R.id.movie_cover_container);

        mCoverContainer.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v)
            {
                getContext().startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("http://www.youtube.com/watch?v=" + movie.get("trailer"))));
            }
        });

        mVideosGroup=(ViewGroup) rootView.findViewById(R.id.movie_videos_container);

        View videoView = inflater.inflate(R.layout.item_video, mVideosGroup, false);
        videoNameView =(TextView) findById(videoView, R.id.video_name);
        videoNameView.setText(movie.get("videosite") + ": " + movie.get("videoname"));
        videoNameView.setVisibility(View.VISIBLE);
        videoView.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                getContext().startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("http://www.youtube.com/watch?v=" + movie.get("trailer"))));
            }
        });

        mVideosGroup.addView(videoView);



       // movie_stars.setText((String)movie.get("stars"));
       // movie_director.setText((String) movie.get("director"));
       /* Double rates = (Double)movie.get("rating");
        movie_rating.setRating(rates.floatValue() / 2);
        movie_rating_text.setText(rates.toString());*/

        mPosterPlayImage=(ImageView) rootView.findViewById(R.id.movie_poster_play);
        mPosterPlayImage.setVisibility(View.VISIBLE);
        mVideosGroup.setVisibility(View.VISIBLE);

        return rootView;
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {

        inflater.inflate(R.menu.fragment_movie, menu);
        mMenuItemShare = menu.findItem(R.id.shareaction);
        MenuItem shareItem = menu.findItem(R.id.shareaction);
        //mShareActionProvider= (ShareActionProvider) shareItem.getActionProvider();
        mShareActionProvider = (ShareActionProvider) MenuItemCompat.getActionProvider(shareItem);
        Intent intentShare = new Intent(Intent.ACTION_SEND);
        intentShare.setType("text/plain");
        intentShare.putExtra(Intent.EXTRA_TEXT, (String) movie.get("name"));
        mShareActionProvider.setShareIntent(intentShare);



        super.onCreateOptionsMenu(menu, inflater);

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        shareTrailer(R.string.share_template,(String) movie.get("videosite"));
        return true;
    }
    public void shareTrailer(int messageTemplateResId, String videosite) {

        mContext.startActivity(Intent.createChooser(createShareIntent(messageTemplateResId, videosite),
                mContext.getString(R.string.title_share_trailer)));
    }
    public Intent createShareIntent(int messageTemplateResId, String title) {
        ShareCompat.IntentBuilder builder = ShareCompat.IntentBuilder.from(getActivity())
                .setType("text/plain")
                .setText(mContext.getString(messageTemplateResId, title, " http://www.youtube.com/watch?v=" ));
        return builder.getIntent();
    }


    /*@Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        System.out.println("999999999999999R.menu.menu_fragement_detail"+R.menu.fragment_movie);
        inflater.inflate(R.menu.fragment_movie, menu);
        MenuItem shareItem = menu.findItem(R.id.shareaction);
        //mShareActionProvider= (ShareActionProvider) shareItem.getActionProvider();
        mShareActionProvider = (ShareActionProvider) MenuItemCompat.getActionProvider(shareItem);

        Intent intentShare = new Intent(Intent.ACTION_SEND);
        intentShare.setType("text/plain");
        intentShare.putExtra(Intent.EXTRA_TEXT, (String) movie.get("name"));
        mShareActionProvider.setShareIntent(intentShare);



       super.onCreateOptionsMenu(menu, inflater);


    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        return super.onOptionsItemSelected(item);
    }*/


    @Override
    public void onScrollChanged(int scrollY, boolean firstScroll, boolean dragging) {

        ViewCompat.setTranslationY(mCoverContainer, scrollY / 2);

        if (mToolbar != null) {
            int parallaxImageHeight = mCoverContainer.getMeasuredHeight();
            float alpha = Math.min(1, (float) scrollY / parallaxImageHeight);
            mToolbar.setBackgroundColor(ScrollUtils.getColorWithAlpha(alpha, mColorThemePrimary));
            mToolbar.setTitleTextColor(ScrollUtils.getColorWithAlpha(alpha, mColorTextWhite));
        }
    }
    @Override
    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putParcelable(STATE_SCROLL_VIEW, mScrollView.onSaveInstanceState());
    }
    private void trySetupToolbar() {

        if (getActivity() instanceof Movies_MovieDetailsActivity) {
            Movies_MovieDetailsActivity activity = ((Movies_MovieDetailsActivity) getActivity());

            mToolbar=activity.getToolbar();
            mToolbar.setTitle((String)movie.get("name"));
        }
    }


    @Override
    public void onDownMotionEvent() { /** ignore */}

    @Override
    public void onUpOrCancelMotionEvent(ScrollState scrollState) { /** ignore */}

}
