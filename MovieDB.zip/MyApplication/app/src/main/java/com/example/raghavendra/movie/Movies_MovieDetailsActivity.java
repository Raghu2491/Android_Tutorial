package com.example.raghavendra.movie;

import android.os.Bundle;
import android.support.v4.view.ViewCompat;
import android.support.v7.app.ActionBar;
import android.view.View;

import java.util.HashMap;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;

/**
 * Created by Raghavendra on 4/25/2016.
 */
public final class Movies_MovieDetailsActivity extends AppCompatActivity {
    public static final String EXTRA_MOVIE = "MOVIE_DETAIL";
    private static final String MOVIE_FRAGMENT_TAG = "fragment_movie";
    Movies_MovieData md=new Movies_MovieData();
    protected Toolbar mToolbar;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_movie_details);
        mToolbar = (Toolbar) findViewById(R.id.toolbar2);

        if (mToolbar != null) {
            ViewCompat.setElevation(mToolbar, getResources().getDimension(R.dimen.toolbar_elevation));
            // mToolbar.setNavigationOnClickListener(view -> finish());
            mToolbar.setNavigationOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    System.exit(0);
                }
            });


            ActionBar ab = getSupportActionBar();
            if (ab != null) {
                ab.setDisplayOptions(0, ActionBar.DISPLAY_SHOW_TITLE);
                ab.setDisplayHomeAsUpEnabled(true);
                ab.setDisplayShowHomeEnabled(true);
            }
        }





        HashMap<String, ?>  moviepos=(HashMap<String,?>)getIntent().getSerializableExtra(EXTRA_MOVIE);


           Movies_Details_Fragment fragment = Movies_Details_Fragment.newInstance(moviepos);
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.movie_details_container, fragment, MOVIE_FRAGMENT_TAG)
                    .commit();

    }
    @Nullable
    public final Toolbar getToolbar() {
        return mToolbar;
    }

}
