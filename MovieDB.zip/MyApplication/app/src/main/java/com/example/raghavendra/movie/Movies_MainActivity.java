package com.example.raghavendra.movie;

import android.support.annotation.Nullable;
import android.support.v4.view.ViewCompat;
import android.support.v7.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.app.ActionBar;
import android.support.v7.widget.Toolbar;
import android.view.View;


import java.util.HashMap;


/**
 * Created by Raghavendra
 * on 4/23/2016.
 */
public class Movies_MainActivity extends AppCompatActivity implements Movies_RecyclerViewFragment.OnEachCardItemSelectedListener
{

    private Fragment mContent;
    protected Toolbar mToolbar;
    private boolean mTwoPane;
    private static final String MOVIE_DETAILS_FRAGMENT_TAG = "fragment_movie_details";
    Movies_MovieData moviesMovieData = new Movies_MovieData();
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_browse_movies);
        mToolbar = (Toolbar) findViewById(R.id.toolbar2);
        setSupportActionBar(mToolbar);
        mTwoPane = findViewById(R.id.movie_details_container) != null;
        //ActionBar actionBar = getSupportActionBar();
        //actionBar.setDisplayHomeAsUpEnabled(true);


        ViewCompat.setElevation(mToolbar, getResources().getDimension(R.dimen.toolbar_elevation));
        setSupportActionBar(mToolbar);
        ActionBar actionBar = getSupportActionBar();
        if (actionBar == null) return;
        actionBar.setDisplayHomeAsUpEnabled(false);
        actionBar.setHomeButtonEnabled(false);

        if(mTwoPane)
        {
            HashMap<String,?> movie = (HashMap<String,?>) moviesMovieData.findFirst(1);
            Movies_Details_Fragment fragment = Movies_Details_Fragment.newInstance(movie);
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.movie_details_container, fragment, MOVIE_DETAILS_FRAGMENT_TAG)
                    .setCustomAnimations(R.anim.slide_in_right, R.anim.slide_out_left, R.anim.slide_in_left, R.anim.slide_out_right)
                    .commit();
        }
        else {

            HashMap<String, ?> movie = (HashMap<String, ?>) moviesMovieData.findFirst(1);
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.movies_container, Movies_RecyclerViewFragment.newInstance(movie))
                    .commit();
        }





    }
    @Override
    public void OnEachCardSelected(int position, HashMap<String, ?> movie,View sharedview) {
        //setContentView(R.layout.activity_movie_details);



      /*  mContent =  Movies_Details_Fragment.newInstance(movie);
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.movies_container, mContent)
                .addToBackStack(null)
                .commit();*/
        System.out.println("----------------- SEE movies_container IN OnEachCardSelected "+R.id.movies_container);
        Intent intent=new Intent(this, Movies_MovieDetailsActivity.class);
        intent.putExtra(Movies_MovieDetailsActivity.EXTRA_MOVIE,movie);

        startActivity(intent);

    }

    @Nullable
    public final Toolbar getToolbar() {
        return mToolbar;
    }



    public void onCardClick(View view, int position)
    {
        System.out.println(" (((((((((((((((((((((((((((((((((((((((((((((((((((((((((((( ");
    }

}
