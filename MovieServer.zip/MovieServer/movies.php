<?php

function getDB(){
	$dbhost = "localhost";
	$dbuser="root";
	$dbpass="";
	$dbname="androidmoviesdb";
	
	$conn = new mysqli($dbhost, $dbuser, $dbpass, $dbname);
	if($conn->connect_error){
		die("Connection Failed: " . $conn->connect_error."\n");
	}
	
	return $conn;
	
}

function getMovies(){
	$conn = getDb();
	
	$sql = "SELECT * FROM Movies ORDER BY name ASC";
	
	if(!$result = $conn->query($sql)){
		die('Error running the query ['.$conn->error.']\n');
	}
	
	$return_arr = array();
	
	while($row = $result->fetch_assoc()){
		$row_array['id'] = $row['id'];
		$row_array['name'] = $row['name'];
		$row_array['description'] = $row['description'];
		$row_array['rating'] = $row['rating'];
		$row_array['url'] = $row['url'];
		$row_array['year'] = "".$row['year'];
		$row_array['director'] = $row['director'];
		$row_array['stars'] = $row['stars'];
		$row_array['length'] = $row['length'];
		$row_array['image'] = $row['image'];
		array_push($return_arr, $row_array);
	}
	
	echo json_encode($return_arr);
	
	$conn->close();
}

function getMovieDetail($ids){
	$conn = getDB();
	
	if($stmt = $conn->prepare("SELECT * FROM Movies WHERE id = ? ")){
		$stmt->bind_param("s",$ids);
		$stmt->execute();
		$res = $stmt->get_result();
		
		$return_arr = array();
		while($row = $res->fetch_assoc()){
		
		$row_array['id'] = $row['id'];
		$row_array['name'] = $row['name'];
		$row_array['description'] = $row['description'];
		$row_array['rating'] = $row['rating'];
		$row_array['url'] = $row['url'];
		$row_array['year'] = "".$row['year'];
		$row_array['director'] = $row['director'];
		$row_array['stars'] = $row['stars'];
		
		array_push($return_arr, $row_array);
			//array_push($return_arr,$row);
		}
		$stmt->close();
	}
	echo json_encode($return_arr);
	$conn->close();
}

function getMoviesAboveRate($rate){
	$conn = getDB();
	
	if($stmt = $conn->prepare("SELECT * FROM Movies WHERE rating >= ? ORDER BY rating DESC")){
		$stmt->bind_param("s",$rate);
		$stmt->execute();
		$res = $stmt->get_result();
		
		$return_arr = array();
		while($row = $res->fetch_assoc()){
		$row_array['id'] = $row['id'];
		$row_array['name'] = $row['name'];
		$row_array['description'] = $row['description'];
		$row_array['rating'] = $row['rating'];
		$row_array['url'] = $row['url'];
		$row_array['year'] = "".$row['year'];
		$row_array['director'] = $row['director'];
		$row_array['stars'] = $row['stars'];
		$row_array['length'] = $row['length'];
		$row_array['image'] = $row['image'];
		
		array_push($return_arr, $row_array);
		}
		$stmt->close();
	}
	echo json_encode($return_arr);
	$conn->close();
}

function addMovie($name){
		//$data = $data->getParsedBody();
		
		$conn = getDB();
		
		if($stmt = $conn->prepare("INSERT INTO Movies (id,name,description,stars,length,image,year,rating,director,url) VALUES (?,?,?,?,?,?,?,?,?,?)")){
		$stmt->bind_param("ssssssidss",$name['id'],$name['name'],$name['description'],$name['stars'],$name['length'],$name['image'],$name['year'],$name['rating'],$name['director'],$name['url']);
		$stmt->execute();
		$stmt->close();
	}
	$conn->close();
}

function deleteMovie($name){
	//$data = $name->getParsedBody();
	$conn = getDB();
	echo $name['id'];
	if($stmt = $conn->prepare("DELETE FROM Movies WHERE id = ?")){
		$stmt->bind_param("s",$name['id']);
		$stmt->execute();
		$stmt->close();
	}
	$conn->close();
}
?>