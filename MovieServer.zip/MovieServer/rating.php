<?php

function getMoviesAboveRating_NotSafe($rating)
{
	$conn=getDB();
	
	if($stmt=$conn->prepare("SELECT id,name,description,rating,url
								FROM Movies
								WHERE rating>=?
								ORDER BY rating DESC")){
	$stmt->bind_param("s",$rating);
	
	$stmt->execute();
	
	$result=$stmt->get_result();
	
	$return_arr=array();
	while($row=$result->fetch_assoc()){
		array_push($return_arr,$row);
	}
	
	$stmt->close();
	} 
	
	echo json_encode($return_arr);
	$conn->close();
}

