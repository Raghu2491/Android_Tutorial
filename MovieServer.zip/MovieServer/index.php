<?php
	require '../vendor/autoload.php';
	require '../ExampleApp/movies.php';
	$app = new \Slim\App;
	
	$app->get(
	'/',
	function(){
		echo "<h1>Android Programming 7</h1>";
		echo "<h1>Delete Movie</h1>";
		echo "<form action=\"http://www.example.com/delete\" method=\"post\">";
		echo "<p>Enter the movie ID to be deleted: <p><br>";
		echo "ID Name: <input type=\text\" name=\"idname\"><br>";
		echo "<input type=\"submit\" value=\"Delete\">";
		echo "</form>";
		
		echo "<h1>Add Movie</h1>";
		echo "<form action=\"http://www.example.com/add\" method=\"post\">";
		echo "<p>Enter the movie information to be added: <p><br>";
		echo "Movie ID: <input type=\text\" name=\"movieid\">";
		echo "Movie Name: <input type=\text\" name=\"name\"><br>";
		echo "Movie Desc: <input type=\text\" name=\"description\"><br>";
		echo "Stars: <input type=\text\" name=\"stars\"><br>";
		echo "Length: <input type=\text\" name=\"length\">";
		echo "Image: <input type=\text\" name=\"image\">";
		echo "Rating: <input type=\text\" name=\"rating\">";
		echo "Year: <input type=\text\" name=\"year\">";
		echo "Director: <input type=\text\" name=\"director\"><br>";
		echo "URL: <input type=\text\" name=\"url\"><br>";
		echo "<input type=\"submit\" value=\"Add\">";
		echo "</form>";
		
	}
	);
	
	$app->get(
	'/movies/',
	function(){
		//echo "Hello Movies";
		getMovies();
	}
	);
	
	$app->get(
	'/movies/id/{mid}',
	function($request, $response, $args){
		//echo "Hello, ".$args['mid'];
		getMovieDetail($args['mid']);
	}
	);
	
	$app->get(
	'/movies/rating/{rate}',
	function($request, $response, $args){
		getMoviesAboveRate($args['rate']);
	}
	);
	
	
	$app->post(
	'/delete',
	function($request, $response, $args){
		echo 'Post Delete<br>';
		$movie = json_decode($request->getBody(),true);
		echo $movie['id'];
		deleteMovie($movie);
	}
	);
	
	$app->post(
	'/add',
	function($request, $response, $args){
		echo 'Post Add<br>';
		$movie = json_decode($request->getBody(),true);
		echo $movie['id'];
		addMovie($movie);
	}
	);
	
	$app->put(
	'/put',
	function(){
		echo 'This is a put route';
		
	}
	);
	
	$app->run();
	?>
