package com.example.raghavendra.hw8;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.SearchView;
import android.view.ActionMode;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.OvershootInterpolator;
import android.widget.PopupMenu;
import android.widget.Toast;

import com.baoyz.widget.PullRefreshLayout;

import org.json.JSONObject;

import java.lang.ref.WeakReference;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import jp.wasabeef.recyclerview.adapters.AlphaInAnimationAdapter;
import jp.wasabeef.recyclerview.adapters.SlideInBottomAnimationAdapter;
import jp.wasabeef.recyclerview.animators.FlipInBottomXAnimator;
/**
 * Created by Raghavendra on 3/25/2016.
 */

public class RecyclerViewFragment extends Fragment {
    private RecyclerView mRecyclerView;
    private RecyclerView.LayoutManager mLayoutManager;
    MovieDataJson movieData=new MovieDataJson();
    PullRefreshLayout layout = null;
    private MyRecyclerViewAdapter mRecyclerViewAdapter;
    private static final String ARG_SECTION_NUMBER = "section_number";


    public interface OnEachCardSelectedListener{
        void OnEachCardSelected(HashMap<String, ?> movie);
    }

    OnEachCardSelectedListener mListener;

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        if(menu.findItem(R.id.search)==null)
            inflater.inflate(R.menu.menu_fragment_task,menu);

        SearchView search = (SearchView) menu.findItem(R.id.search).getActionView();

        if(search!=null){
            final List<Map<String,?>> movieList = movieData.getMoviesList();
            search.setOnQueryTextListener(new SearchView.OnQueryTextListener() {

                @Override
                public boolean onQueryTextSubmit(String query) {
                    String rating_url = MovieDataJson.PHP_SERVER+"movies/rating/"+query;
                    MyDownloadMovieDataCard e = new MyDownloadMovieDataCard(mRecyclerViewAdapter);
                    e.execute(rating_url);
                    return false;
                }

                @Override
                public boolean onQueryTextChange(String newText) {
                    return true;
                }
            });
        }
        super.onCreateOptionsMenu(menu, inflater);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        return super.onOptionsItemSelected(item);
    }

    public RecyclerViewFragment() {
        // Required empty public constructor

    }

    public static RecyclerViewFragment newInstance(HashMap<String, ?> sectionNumber) {
        RecyclerViewFragment fragment = new RecyclerViewFragment();
        Bundle args = new Bundle();
        args.putSerializable(ARG_SECTION_NUMBER, sectionNumber);
        fragment.setArguments(args);
        return fragment;
    }

    public static RecyclerViewFragment newInstance(int sectionNumber) {
        RecyclerViewFragment fragment = new RecyclerViewFragment();
        Bundle args = new Bundle();
        args.putInt(ARG_SECTION_NUMBER, sectionNumber);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);

        try{
            mListener =  (OnEachCardSelectedListener)getContext();
        }
        catch(ClassCastException exception){
            throw new ClassCastException(context.toString()
                    + " must implement OnHeadlineSelectedListener");
        }

    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        /*setRetainInstance(true);*/
        setHasOptionsMenu(true);
        movieData = new MovieDataJson();
    }
    public boolean isNetworkAvailable(){
        ConnectivityManager cm = (ConnectivityManager)getContext().getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo info = cm.getActiveNetworkInfo();
        if(info!=null && info.isConnected()){
            return true;
        }
        return false;
    }
    @Override
    public View onCreateView(final LayoutInflater inflater, final ViewGroup container,
                             final Bundle savedInstanceState) {

        final View rootView;
        // Inflate the layout for this fragment
        rootView = inflater.inflate(R.layout.fragment_recyclerview, container, false);
        mRecyclerView = (RecyclerView) rootView.findViewById(R.id.cardList);
        mRecyclerView.setHasFixedSize(true);
        mLayoutManager = new LinearLayoutManager(getActivity());
        mRecyclerView.setLayoutManager(mLayoutManager);
        mRecyclerViewAdapter = new MyRecyclerViewAdapter(getActivity(), movieData.getMoviesList());


        String movieUrl = MovieDataJson.PHP_SERVER + "movies/";
        if(isNetworkAvailable()) {
            MyDownloadMovieDataCard myDownloadMovieDataCard = new MyDownloadMovieDataCard(mRecyclerViewAdapter);
            myDownloadMovieDataCard.execute(movieUrl);
        }

        mRecyclerView.setAdapter(mRecyclerViewAdapter);


        mRecyclerViewAdapter.setOnCardClickListener(new MyRecyclerViewAdapter.onCardClickListener() {
            @Override
            public void onCardClick(View view, int position) {
                HashMap<String, ?> movie = (HashMap<String, ?>) movieData.getItem(position);
                String id = (String) movie.get("id");
                String url = MovieDataJson.PHP_SERVER + "movies/id/" + id;
                if (url != null) {
                    MyDownloadMovieDetail movieDetail = new MyDownloadMovieDetail(mListener);
                    movieDetail.execute(url);
                }
                //mListener.OnEachCardSelected(position, movie);
            }

            @Override
            public void onCardLongClick(View view, int position) {
                getActivity().startActionMode(new ActionBarCallBack(position));
            }

            @Override
            public void onMoreOptionsClick(View view, final int position) {
                PopupMenu popupmenu = new PopupMenu(getActivity(), view);
                popupmenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    @Override
                    public boolean onMenuItemClick(MenuItem item) {
                        switch (item.getItemId()) {
                            case R.id.action_delete:
                                List<Map<String,?>> maps = movieData.getMoviesList();
                                JSONObject json = null;
                                HashMap<String,?> movie = (HashMap)maps.get(position);
                                //if(movie!=null){
                                json=new JSONObject(movie);
                                //}
                                final JSONObject finalJson = json;
                                Runnable runnable = new Runnable() {
                                    @Override
                                    public void run() {
                                        String url = MovieDataJson.PHP_SERVER + "delete";
                                        MyUtility.sendHttPostRequest(url, finalJson);
                                    }
                                };
                                new Thread(runnable).start();
                                maps.remove(position);
                                mRecyclerViewAdapter.notifyItemRemoved(position);
                                return true;
                            case R.id.duplicate:
                                movieData.addItem(position+1,(HashMap)(movieData.getItem(position).clone()));
                                mRecyclerViewAdapter.notifyItemInserted(position+1);
                                return true;
                            default:
                                return false;
                        }
                    }
                });
                MenuInflater inflater = popupmenu.getMenuInflater();
                inflater.inflate(R.menu.menu_popup, popupmenu.getMenu());
                popupmenu.show();
            }
        });


        layout = (PullRefreshLayout) rootView.findViewById(R.id.swipeRefreshLayout);
        layout.setOnRefreshListener(new PullRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                getFragmentManager().beginTransaction()
                        .add(R.id.container, RecyclerViewFragment.newInstance(1))
                        .commit();
                //mRecyclerViewAdapter.notifyItemRangeChanged(0, mRecyclerViewAdapter.getItemCount());
                Toast.makeText(getContext(), "Refreshed", Toast.LENGTH_LONG).show();
                layout.setRefreshing(false);
            }
        });
        layout.setRefreshStyle(PullRefreshLayout.STYLE_MATERIAL);
        itemAnimation();
        adapterAnimation();
        return rootView;
    }
    private void itemAnimation(){
        FlipInBottomXAnimator animator = new FlipInBottomXAnimator();
        animator.setAddDuration(300);
        animator.setRemoveDuration(300);
        mRecyclerView.setItemAnimator(animator);
    }

    private void adapterAnimation(){
        AlphaInAnimationAdapter alphaAdapter = new AlphaInAnimationAdapter(mRecyclerViewAdapter);
        SlideInBottomAnimationAdapter slideAdapter = new SlideInBottomAnimationAdapter(alphaAdapter);
        slideAdapter.setDuration(1000);
        slideAdapter.setInterpolator(new OvershootInterpolator());
        slideAdapter.setFirstOnly(false);
        mRecyclerView.setAdapter(slideAdapter);
    }

    private class ActionBarCallBack implements ActionMode.Callback {
        int position;

        public ActionBarCallBack(int position) {
            this.position = position;
        }

        @Override
        public boolean onCreateActionMode(ActionMode mode, Menu menu) {
            mode.getMenuInflater().inflate(R.menu.menu_popup,menu);
            return true;
        }

        @Override
        public boolean onPrepareActionMode(ActionMode mode, Menu menu) {
            HashMap<String,?> movie = (HashMap<String,?>) movieData.getItem(position);
            mode.setTitle((String) movie.get("name"));
            return false;
        }

        @Override
        public boolean onActionItemClicked(ActionMode mode, MenuItem item) {
            int id = item.getItemId();

            switch (id){

                case R.id.action_delete:
                    List<Map<String,?>> maps = movieData.getMoviesList();
                    JSONObject json = null;
                    HashMap<String,?> movie = (HashMap)maps.get(position);
                    //if(movie!=null){
                    json=new JSONObject(movie);
                    //}
                    final JSONObject finalJson = json;
                    Runnable runnable = new Runnable() {
                        @Override
                        public void run() {
                            String url = MovieDataJson.PHP_SERVER + "delete";
                            MyUtility.sendHttPostRequest(url, finalJson);
                        }
                    };
                    new Thread(runnable).start();
                    maps.remove(position);
                    mRecyclerViewAdapter.notifyItemRemoved(position);
                    mode.finish();
                    break;
                case R.id.duplicate:
                    movieData.addItem(position+1,(HashMap)(movieData.getItem(position).clone()));
                    mRecyclerViewAdapter.notifyItemInserted(position + 1);
                    mode.finish();
                    break;
                default:
                    break;
            }
            return false;
        }

        @Override
        public void onDestroyActionMode(ActionMode mode) {

        }
    }

    private class MyDownloadMovieDataCard extends AsyncTask<String, Void, MovieDataJson> {
        private final WeakReference<MyRecyclerViewAdapter> adapterWeakReference;
        public MyDownloadMovieDataCard(MyRecyclerViewAdapter adapter) {
            adapterWeakReference = new WeakReference<MyRecyclerViewAdapter>(adapter);
        }

        @Override
        protected MovieDataJson doInBackground(String... params) {

            MovieDataJson threadMovieData = new MovieDataJson();
            for(String url: params){
                threadMovieData.downloadMovieDataFromJson(url);
            }
            return threadMovieData;
        }

        @Override
        protected void onPostExecute(MovieDataJson s) {
            movieData.moviesList.clear();
            for(int i=0;i<s.getSize();i++){
                movieData.moviesList.add(s.moviesList.get(i));
            }
            if(adapterWeakReference!=null){
                final MyRecyclerViewAdapter adapter = adapterWeakReference.get();
                if(adapter!=null){
                    adapter.notifyDataSetChanged();
                }
            }
        }
    }

    private class MyDownloadMovieDetail extends AsyncTask<String, Void, HashMap>{
        private WeakReference<OnEachCardSelectedListener> listenerWeakReference;

        public MyDownloadMovieDetail(OnEachCardSelectedListener listener) {
            listenerWeakReference = new WeakReference<OnEachCardSelectedListener>(listener);
        }

        @Override
        protected HashMap doInBackground(String... params) {
            String detailJson ="";
            HashMap<String,?> movieDetail = new HashMap<>();
            for(String url : params){
                //detailJson = MyUtility.downloadJSONusingHTTPGetRequest(url);
                movieDetail = movieData.downloadMovieDetailFromJson(url);
            }
            //movieDetail = movieData.downloadMovieDetailFromJson(detailJson);
            return movieDetail;
        }

        @Override
        protected void onPostExecute(HashMap hashMap) {
            OnEachCardSelectedListener listener = listenerWeakReference.get();
            if(listener!=null){
                listener.OnEachCardSelected(hashMap);
                //mRecyclerViewAdapter.notifyDataSetChanged();
            }
        }
    }


}
