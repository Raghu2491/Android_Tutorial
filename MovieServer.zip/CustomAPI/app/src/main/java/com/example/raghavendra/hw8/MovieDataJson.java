package com.example.raghavendra.hw8;

/**
 * Created by Raghavendra on 3/25/2016.
 */
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.support.annotation.NonNull;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MovieDataJson {

    List<Map<String,?>> moviesList;
    protected static final String PHP_SERVER = "http://www.example.com/";
    public List<Map<String, ?>> getMoviesList() {
        return moviesList;
    }

    public int getSize(){
        return moviesList.size();
    }

    public HashMap getItem(int i){
        if (i >=0 && i < moviesList.size()){
            return (HashMap) moviesList.get(i);
        } else return null;
    }

    public MovieDataJson(){
        moviesList = new ArrayList<Map<String,?>>();
    }

    public void downloadMovieDataFromJson(String jsonStringUrl){
        String name="";
        String description="";
        double rating=0.0;
        String url="";
        String id="";
        String director="";
        String stars="";
        String image="";
        String length="";
        String year="";
        JSONObject movieJsonObj;
        moviesList = new ArrayList<Map<String,?>>();
        try {
            String jsonString = MyUtility.downloadJSONusingHTTPGetRequest(jsonStringUrl);
            JSONArray movieJsonArray = new JSONArray(jsonString);
            for(int i = 0; i <movieJsonArray.length();i++){
                movieJsonObj = (JSONObject) movieJsonArray.get(i);
                if(movieJsonObj!=null){
                    name = (String) movieJsonObj.get("name");
                    description = (String) movieJsonObj.get("description");
                    url = (String) movieJsonObj.get("url");
                    id = (String) movieJsonObj.get("id");
                    rating = movieJsonObj.getDouble("rating");

                    director = (String) movieJsonObj.get("director").toString();
                    year = movieJsonObj.get("year").toString();
                    stars = (String) movieJsonObj.get("stars").toString();
                    length = movieJsonObj.get("length").toString();
                    image = (String) movieJsonObj.get("image").toString();
                }
                moviesList.add(createMovie(name, description, id, rating, url,stars,director,year,length,image));
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }

    }


    private HashMap createMovie(String name, String description, String id, double rating,String url, String stars,String director, String year, String length, String image) {
        HashMap movie = new HashMap();
        movie.put("name", name);
        movie.put("description", description);
        movie.put("rating",rating);
        movie.put("id",id);
        movie.put("url",url);
        movie.put("stars", stars);
        movie.put("director", director);
        movie.put("year",year);
        movie.put("length",length);
        movie.put("image",image);
        return movie;
    }

    public HashMap<String,?> downloadMovieDetailFromJson(String jsonStringUrl) {
        String name = "";
        String description = "";
        double rating = 0.0;
        String url = "";
        String id = "";
        String director = "";
        String stars = "";
        String length = "";
        String year = "";
        JSONObject movieJsonObj;
        moviesList = new ArrayList<Map<String, ?>>();
        try {
            String jsonString = MyUtility.downloadJSONusingHTTPGetRequest(jsonStringUrl);
            JSONArray movieJsonArray = new JSONArray(jsonString);
            if(movieJsonArray!=null) {
                for (int i = 0; i < movieJsonArray.length(); i++) {
                    movieJsonObj = (JSONObject) movieJsonArray.get(i);
                    if (movieJsonObj != null) {
                        name = (String) movieJsonObj.get("name");
                        description = (String) movieJsonObj.get("description");
                        url = (String) movieJsonObj.get("url");
                        id = (String) movieJsonObj.get("id");
                        rating = movieJsonObj.getDouble("rating");
                        stars = (String) movieJsonObj.get("stars");
                        director = (String) movieJsonObj.get("director");
                        year = (String) movieJsonObj.get("year");
                    }

                }
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        HashMap<String,?> movie = createMovieDetail(name, description, id, rating, url, stars, director, year, length);
        return movie;

    }


    private HashMap createMovieDetail(String name, String description, String id, double rating,String url, String stars,String director, String year,String length) {
        HashMap movie = new HashMap();
        movie.put("name", name);
        movie.put("description", description);
        movie.put("rating",rating);
        movie.put("id",id);
        movie.put("url",url);
        movie.put("stars", stars);
        movie.put("director", director);
        movie.put("length",length);
        movie.put("year",year);
        return movie;
    }

    public void addItem(int position, Map item){
        final JSONObject json;
        String newId = (String)item.get("id")+"_new";

        if(item!=null){
            item.put("id", newId);
            json=new JSONObject(item);
        }
        else json=null;
        Runnable runnable = new Runnable() {
            @Override
            public void run() {
                String url = PHP_SERVER + "add";
                MyUtility.sendHttPostRequest(url,json);
            }
        };
        new Thread(runnable).start();
        moviesList.add(position,item);
    }
}
