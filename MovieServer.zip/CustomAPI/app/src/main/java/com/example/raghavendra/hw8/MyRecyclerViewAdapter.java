package com.example.raghavendra.hw8;

/**
 * Created by Raghavendra on 3/25/2016.
 */
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.PorterDuff;
import android.os.AsyncTask;
import android.support.v4.util.LruCache;
import android.support.v7.graphics.Palette;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;

import java.lang.ref.WeakReference;
import java.util.List;
import java.util.Map;

import butterknife.Bind;
import butterknife.BindColor;


public class MyRecyclerViewAdapter extends RecyclerView.Adapter<MyRecyclerViewAdapter.ViewHolder> {
    private List<Map<String,?>> mDataSet;
    private Context mContext;
    private onCardClickListener mCardClickListener;
    private LruCache<String, Bitmap> imgMemoryCache;

    @Override
    public int getItemViewType(int position) {
        Map<String,?> item = mDataSet.get(position);
        Double rating = (Double)item.get("rating");
        return rating.intValue();
        //return super.getItemViewType(position);
    }
    @BindColor(R.color.theme_primary) int mColorBackground;
    @BindColor(R.color.body_text_white) int mColorTitle;
    @BindColor(R.color.body_text_1_inverse) int mColorSubtitle;



    public MyRecyclerViewAdapter(Context myContext, List<Map<String, ?>> mDataSet){
        this.mContext=myContext;
        this.mDataSet=mDataSet;

        if (imgMemoryCache== null) {
            final int maxMemory = (int) (Runtime.getRuntime().maxMemory() / 1024);

            // Use 1/8th of the available memory for this memory cache.
            final int cacheSize = maxMemory / 8;

            imgMemoryCache = new LruCache<String, Bitmap>(cacheSize) {
                @Override
                protected int sizeOf(String key, Bitmap bitmap) {
                    // The cache size will be measured in kilobytes rather than
                    // number of items.
                    return bitmap.getByteCount() / 1024;
                }
            };
        }
    }

    @Override
    public MyRecyclerViewAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v;
        v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.fragment_cardview, parent, false);
        ViewHolder vh = new ViewHolder(v);
        return vh;
    }

    @Override
    public void onBindViewHolder(MyRecyclerViewAdapter.ViewHolder holder, int position) {
        Map<String, ?> movie = mDataSet.get(position);
        //holder.vIcon.setImageResource((Integer) movie.get("image"));
        holder.vTitle.setText((String) movie.get("name"));
        holder.vDescription.setText((String) movie.get("description"));
        Double rates = (Double)movie.get("rating");
        holder.vRatingbar.setRating(rates.floatValue() / 2);
        holder.vRatingText.setText("(" + rates.toString() + ")");



        //load image to vIcon
        String imgUrl = (String) movie.get("url");
        final Bitmap bitmap = imgMemoryCache.get(imgUrl);

        Palette palette  = Palette.from(bitmap).generate();
        Palette.Swatch swatch = palette.getVibrantSwatch();

        holder.vDescription.setBackgroundColor(swatch.getBodyTextColor());
        holder.vTitle.setBackgroundColor(swatch.getTitleTextColor());

        if(bitmap!=null){
            holder.vIcon.setImageBitmap(bitmap);
        }
        else {
            MyImageDownload myImageDownload = new MyImageDownload(holder.vIcon);
            myImageDownload.execute(imgUrl);
        }

        /*Bitmap icon = MyUtility.downloadImageusingHTTPGetRequest(imgUrl);
        holder.vIcon.setImageBitmap(icon);*/
    }


    @Override
    public int getItemCount() {
        return mDataSet.size();
    }


    public class ViewHolder extends RecyclerView.ViewHolder {
        public ImageView vIcon;
        public TextView vTitle;
        public TextView vDescription;
        public ImageView vMoreOptions;
        public RatingBar vRatingbar;
        public TextView vRatingText;

        public ViewHolder(View itemView) {

            super(itemView);
            vIcon = (ImageView) itemView.findViewById(R.id.movieCard);
            vTitle = (TextView) itemView.findViewById(R.id.movietitle);
            vDescription = (TextView) itemView.findViewById(R.id.description);
            vMoreOptions = (ImageView) itemView.findViewById(R.id.selection);
            vRatingbar = (RatingBar) itemView.findViewById(R.id.rating);
            vRatingText = (TextView) itemView.findViewById(R.id.ratingTextCard);



            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(mCardClickListener!=null)
                        mCardClickListener.onCardClick(v,getPosition());
                }
            });

            itemView.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View v) {
                    if (mCardClickListener != null)
                        mCardClickListener.onCardLongClick(v, getPosition());
                    return true;
                }
            });
            if(vMoreOptions!=null) {
                vMoreOptions.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if(mCardClickListener!=null){
                            mCardClickListener.onMoreOptionsClick(v,getPosition());
                        }
                    }
                });
            }

        }
    }

    public interface onCardClickListener{
        void onCardClick(View view, int position);
        void onCardLongClick(View view, int position);
        void onMoreOptionsClick(View view, int position);
    }

    public void setOnCardClickListener(final onCardClickListener mCardClickListener){
        this.mCardClickListener = mCardClickListener;
    }

    private class MyImageDownload extends AsyncTask<String, Void, Bitmap>{
        private WeakReference<ImageView> imageViewWeakReference;
        public MyImageDownload(ImageView img) {
            imageViewWeakReference = new WeakReference<ImageView>(img);
        }

        @Override
        protected Bitmap doInBackground(String... params) {
            Bitmap icon = null;
            for(String url : params) {
                icon = MyUtility.downloadImageusingHTTPGetRequest(url);
                if(icon!=null){
                    imgMemoryCache.put(url,icon);
                }
            }
            return icon;
        }

        @Override
        protected void onPostExecute(Bitmap bitmap) {
            if(imageViewWeakReference!=null && bitmap!=null){
                final ImageView imageView = imageViewWeakReference.get();
                if(imageView!=null){
                    imageView.setImageBitmap(bitmap);
                }
            }
        }
    }
}
