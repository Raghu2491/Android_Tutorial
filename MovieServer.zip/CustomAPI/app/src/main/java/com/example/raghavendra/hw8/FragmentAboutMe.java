package com.example.raghavendra.hw8;

/**
 * Created by Raghavendra on 3/25/2016.
 */
import android.os.Bundle;

import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

public class FragmentAboutMe extends Fragment {
    private static final String ARG_SECTION_NUMBER = "section_number";


    public FragmentAboutMe() {
        // Required empty public constructor

    }

    public static FragmentAboutMe newInstance(int sectionNumber) {
        FragmentAboutMe fragment = new FragmentAboutMe();
        Bundle args = new Bundle();
        args.putInt(ARG_SECTION_NUMBER, sectionNumber);
        fragment.setArguments(args);
        return fragment;
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setHasOptionsMenu(true);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View rootView;
        rootView = inflater.inflate(R.layout.fragment_frontpageabtme, container, false);

        return rootView;
    }

}

