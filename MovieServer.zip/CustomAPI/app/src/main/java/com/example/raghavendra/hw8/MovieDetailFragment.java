package com.example.raghavendra.hw8;

/**
 * Created by Raghavendra on 3/25/2016.
 */
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.util.LruCache;
import android.support.v4.view.MenuItemCompat;
import android.support.v7.widget.ShareActionProvider;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;

import java.lang.ref.WeakReference;
import java.util.HashMap;


public class MovieDetailFragment extends Fragment {
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_SECTION_NUMBER = "section_number";
    private LruCache<String, Bitmap> imgMemoryCache;
    MovieDataJson movieData=new MovieDataJson();
    HashMap movie;
    private ShareActionProvider mShareActionProvider;

    public MovieDetailFragment() {
        // Required empty public constructor

    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param sectionNumber Parameter 1.
     * @return A new instance of fragment FrontPage.
     */
    // TODO: Rename and change types and number of parameters
    public static MovieDetailFragment newInstance(HashMap<String, ?> sectionNumber) {
        MovieDetailFragment fragment = new MovieDetailFragment();
        Bundle args = new Bundle();
        args.putSerializable(ARG_SECTION_NUMBER, sectionNumber);
        fragment.setArguments(args);


        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView=null;
        // Inflate the layout for this fragment
        if (getArguments() != null) {
            movie = (HashMap<String, ?>) getArguments().getSerializable(ARG_SECTION_NUMBER);
        }
        if (imgMemoryCache== null) {
            final int maxMemory = (int) (Runtime.getRuntime().maxMemory() / 1024);

            // Use 1/8th of the available memory for this memory cache.
            final int cacheSize = maxMemory / 8;

            imgMemoryCache = new LruCache<String, Bitmap>(cacheSize) {
                @Override
                protected int sizeOf(String key, Bitmap bitmap) {
                    // The cache size will be measured in kilobytes rather than
                    // number of items.
                    return bitmap.getByteCount() / 1024;
                }
            };
        }
        rootView = inflater.inflate(R.layout.fragment_moviedetail, container, false);

        ImageView movie_poster = (ImageView) rootView.findViewById(R.id.icon);
        TextView movie_title = (TextView) rootView.findViewById(R.id.title);
        TextView movie_stars = (TextView) rootView.findViewById(R.id.starsname);
        TextView movie_year = (TextView) rootView.findViewById(R.id.year);
        TextView movie_desc = (TextView) rootView.findViewById(R.id.descrip);
        RatingBar movie_rating = (RatingBar) rootView.findViewById(R.id.rating);
        TextView movie_director = (TextView) rootView.findViewById(R.id.directorname);
        TextView movie_rating_text = (TextView) rootView.findViewById(R.id.ratingText);

        movie_title.setText((String) movie.get("name"));
        movie_stars.setText((String)movie.get("stars"));
        movie_year.setText("(" + (String) movie.get("year") + ")");
        movie_desc.setText((String)movie.get("description"));
        movie_director.setText((String) movie.get("director"));
        Double rates = (Double)movie.get("rating");
        movie_rating.setRating(rates.floatValue()/2);
        movie_rating_text.setText(rates.toString());

        String imgUrl = (String) movie.get("url");
        final Bitmap bitmap = imgMemoryCache.get(imgUrl);
        if(bitmap!=null){
            movie_poster.setImageBitmap(bitmap);
        }
        else {
            MyImageDownload myImageDownload = new MyImageDownload(movie_poster);
            myImageDownload.execute(imgUrl);
        }
        return rootView;
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        inflater.inflate(R.menu.menu_fragement_detail, menu);
        MenuItem shareItem = menu.findItem(R.id.share);
        mShareActionProvider = (ShareActionProvider) MenuItemCompat.getActionProvider(shareItem);

        Intent intentShare = new Intent(Intent.ACTION_SEND);
        intentShare.setType("text/plain");
        intentShare.putExtra(Intent.EXTRA_TEXT, (String)movie.get("name"));
        mShareActionProvider.setShareIntent(intentShare);

        super.onCreateOptionsMenu(menu, inflater);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        return super.onOptionsItemSelected(item);
    }

    private class MyImageDownload extends AsyncTask<String, Void, Bitmap> {
        private WeakReference<ImageView> imageViewWeakReference;
        public MyImageDownload(ImageView img) {
            imageViewWeakReference = new WeakReference<ImageView>(img);
        }

        @Override
        protected Bitmap doInBackground(String... params) {
            Bitmap icon = null;
            for(String url : params) {
                icon = MyUtility.downloadImageusingHTTPGetRequest(url);
                if(icon!=null){
                    imgMemoryCache.put(url,icon);
                }
            }
            return icon;
        }

        @Override
        protected void onPostExecute(Bitmap bitmap) {
            if(imageViewWeakReference!=null && bitmap!=null){
                final ImageView imageView = imageViewWeakReference.get();
                if(imageView!=null){
                    imageView.setImageBitmap(bitmap);
                }
            }
        }
    }
}
